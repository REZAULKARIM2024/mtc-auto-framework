package Z_alldemoSamples;

public class CastUnderstanding {

	public static void main(String[] args) {
		
		//// Casting 
		String aString = "XYZ";
		
		String o;
		
		o=(String)aString;
		

	}

}
