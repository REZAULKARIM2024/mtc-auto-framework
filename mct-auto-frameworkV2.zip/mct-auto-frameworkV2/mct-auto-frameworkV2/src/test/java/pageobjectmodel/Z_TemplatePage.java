package pageobjectmodel;

import org.openqa.selenium.WebDriver;

public class Z_TemplatePage extends PageParent {


	
	///// ////// Properties XAPTH Id Locators of this Page  /////////////////
	String locatorsTempate = "locators value";
	
	
	///// COnstructor 
	public Z_TemplatePage(WebDriver driver) {		
		super(driver);
	}
	
	

	
	////////////////   My Account Page all Click Operation Together ////////////////
	


	////////////////  My Account Page all Enter Operation Together ////////////////

	


	////////////////   My Account Page all Get Text Operation Together ////////////////


}
